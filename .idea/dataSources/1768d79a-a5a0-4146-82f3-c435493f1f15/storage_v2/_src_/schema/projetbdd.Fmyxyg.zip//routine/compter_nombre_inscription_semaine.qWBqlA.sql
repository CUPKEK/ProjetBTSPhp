create
    definer = root@localhost procedure compter_nombre_inscription_semaine()
BEGIN
    SELECT COUNT(*) FROM client
    WHERE dateAjout >= NOW() - 7;                          
END;

