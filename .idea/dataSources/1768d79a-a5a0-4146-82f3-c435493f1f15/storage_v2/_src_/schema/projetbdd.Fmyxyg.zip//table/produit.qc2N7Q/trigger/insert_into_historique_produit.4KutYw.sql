create definer = root@localhost trigger insert_into_historique_produit
    after UPDATE
    on produit
    for each row
BEGIN 
IF NEW.StockProduit = 0 THEN
BEGIN
INSERT INTO historique_produit(
          idProduit,
          PrixProduit,
          PoidProduit,
          NomProduit,
          DescriptionProduit,
          CouleurProduit,
          idclient,
          dateDelete)
          VALUES(
          OLD.idProduit,
          OLD.PrixProduit,
          OLD.PoidProduit,
          OLD.NomProduit,
          OLD.DescriptionProduit,
          OLD.CouleurProduit,
          OLD.idclient,
          NOW());
END;
END IF;
END;

