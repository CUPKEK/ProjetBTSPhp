create definer = root@localhost trigger date_inscription
    before INSERT
    on client
    for each row
BEGIN
SET NEW.dateAjout = NOW();
END;

