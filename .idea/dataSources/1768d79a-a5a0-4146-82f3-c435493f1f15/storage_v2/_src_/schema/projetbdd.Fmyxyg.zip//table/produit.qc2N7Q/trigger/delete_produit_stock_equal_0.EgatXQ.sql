create definer = root@localhost trigger delete_produit_stock_equal_0
    before DELETE
    on produit
    for each row
BEGIN
IF OLD.StockProduit = 0 THEN
DELETE FROM produit;
END IF;
END;

