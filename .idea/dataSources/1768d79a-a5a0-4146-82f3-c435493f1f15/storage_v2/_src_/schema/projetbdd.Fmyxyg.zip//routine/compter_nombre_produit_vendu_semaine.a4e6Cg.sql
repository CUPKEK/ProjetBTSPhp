create
    definer = root@localhost procedure compter_nombre_produit_vendu_semaine()
BEGIN
    SELECT COUNT(*) FROM historique_produit
    WHERE dateDelete >= NOW() - 7;
END;

